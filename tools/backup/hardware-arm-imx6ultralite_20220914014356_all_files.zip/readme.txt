; --------------------------------------------------------------------------------
; @Title: Readme for i.MX6 UltraLite
; @Description:
; @Keywords: ARM, Cortex-A7
; @Author: AME
; @Board: -
; @Chip: IMX6ULTRALITE IMX6ULL
; @Props: ZIP
; @Copyright: (C) 1989-2022 Lauterbach GmbH, licensed for use with TRACE32(R) only
; --------------------------------------------------------------------------------
; $Id: readme.txt 18877 2022-02-02 07:04:07Z bschroefel $

Example files are written for MCIMX6UL/MCIMX6ULL but should also work for other boards.